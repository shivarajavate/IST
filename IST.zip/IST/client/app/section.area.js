
class SectionArea {
    constructor() {
        
        this.x;
        this.y;

        this.sectionID = -1;
    }

    init(x, y, sectionID) {
        
        this.x = x;
        this.y = y;

        this.sectionID = sectionID;
    }
}