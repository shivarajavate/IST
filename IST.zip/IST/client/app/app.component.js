import template from './app.component.html';
import './app.component.scss';

const AppComponent = {
  template
};

export default AppComponent;